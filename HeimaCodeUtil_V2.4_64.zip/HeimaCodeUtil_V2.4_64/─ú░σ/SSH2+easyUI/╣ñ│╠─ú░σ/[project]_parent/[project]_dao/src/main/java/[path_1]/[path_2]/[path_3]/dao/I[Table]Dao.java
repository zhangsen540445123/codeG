package [package].dao;

import [package].entity.[Table];
/**
 * [comment]数据访问接口
 * @author Administrator
 *
 */
public interface I[Table]Dao extends IBaseDao<[Table]>{
	
	
}
