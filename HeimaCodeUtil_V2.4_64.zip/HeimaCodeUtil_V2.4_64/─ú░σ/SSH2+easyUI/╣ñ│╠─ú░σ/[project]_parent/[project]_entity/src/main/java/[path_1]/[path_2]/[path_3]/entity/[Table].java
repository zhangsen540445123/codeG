package [package].entity;
/**
 * [comment]实体类
 * @author Administrator *
 */
public class [Table] {	
<实体类私有属性.txt>
<实体类公有方法.txt>
}
