package [package].dao;

import org.springframework.data.jpa.repository.JpaRepository;

import [package].entity.[Table];
/**
 * [comment]Dao
 * @author Administrator
 *
 */
public interface I[Table]Dao extends JpaRepository<[Table], Long>{

}
